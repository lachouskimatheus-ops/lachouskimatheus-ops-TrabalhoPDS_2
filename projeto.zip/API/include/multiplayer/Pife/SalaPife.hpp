#ifndef SALA_PIFE_HPP
#define SALA_PIFE_HPP

#include <string>
#include <vector>
#include <crow_all.h>

#include "coreAPI/SalaBase.hpp"
#include "pife.h"

struct ConexaoPife {
    int idJogador;
    crow::websocket::connection* conexao;
};

class SalaPife : public SalaBase {
private:
    Pife jogo_;
    std::vector<ConexaoPife> conexoes_;

public:
    SalaPife(const std::string& idSala, int maxJogadores);

    int adicionarJogador(crow::websocket::connection* conn);

    Pife& jogo();

    std::vector<ConexaoPife>& conexoes();
};

#endif